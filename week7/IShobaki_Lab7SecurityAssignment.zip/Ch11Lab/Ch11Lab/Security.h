//#pragma once
#include <iostream>
using namespace std;
#ifndef SECURITY_H
#define SECURITY_H


class Security
{
public:
	static int validate(string username, string password);
};

#endif // !SECURITY_H




