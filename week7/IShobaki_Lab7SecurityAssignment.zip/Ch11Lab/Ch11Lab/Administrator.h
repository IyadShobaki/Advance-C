//#pragma once

#include <iostream>
using namespace std;

#ifndef ADMINISTRATOR_H
#define ADMINISTRATOR_H
//#ifndef SECURITY_H
//#define SECURITY_H

	class Administrator
	{
		
	public:

		static int Login(string username, string password);
	
	};



//#endif // !SECURITY_H
#endif // !ADMINISTRATOR_H

