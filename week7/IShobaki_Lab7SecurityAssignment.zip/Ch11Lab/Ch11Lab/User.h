//#pragma once

#include <iostream>
using namespace std;
#ifndef USER_H
#define USER_H


class User
{
public:

	static int Login(string username, string password);
};


#endif // !USER_H




